import React from "react";

export default function footer() {
  return (
    <div className="bg-matiLampu text-white-cahaya w-full text-center p-4">
      © 2021 PT. Pharmasolindo{" "}
    </div>
  );
}
